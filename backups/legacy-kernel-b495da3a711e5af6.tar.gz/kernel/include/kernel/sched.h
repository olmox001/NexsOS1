#ifndef _KERNEL_SCHED_H
#define _KERNEL_SCHED_H

#include <drivers/timer.h>
#include <kernel/list.h>
#include <kernel/nx_contract.h>
#include <kernel/spinlock.h>
#include <kernel/types.h>
#include <stdint.h>
#pragma GCC optimize("O2")

#define PROCESS_NAME_MAX 32
#define STACK_SIZE 131072
#define MAX_PRIO 32

/* Process Info for Diagnostics */
struct ps_info {
  int pid;
  char name[32];
  int state;
  int priority;
  uint64_t cpu_time;
  int on_cpu;
};

struct ipc_node {
  struct ipc_message msg;
  struct list_head list;
};

/* Architecture-specific register frame layout */
#include <arch/pt_regs.h>

/* Scheduler time-slice in ticks (HZ=100 -> 10ms/tick).  Lowered from 10 (100ms)
 * to 3 (30ms): the old quantum let a CPU-bound task hog a core for 100ms before
 * an interactive task could preempt it (a real responsiveness tax).  ASID/PCID-
 * tagged switches (perf §3) made context switches cheap, so the finer quantum's
 * extra switches are nearly free — better interactivity at negligible
 * throughput cost. */
#define DEFAULT_QUANTUM 3

/* Wait Queue */
struct wait_queue_head {
  struct list_head task_list;
  spinlock_t lock;
};

struct handle_entry; /* kernel/object.h — capability handle table slot */

/* Per-process ENVIRONMENT (Phase 17).
 *
 * The environment is per-process state that is INHERITED at spawn and mutable
 * by its owner — exactly the shape of cwd, which already lives here.  Keeping
 * it in the kernel is the Phase 5b rule applied consistently: state the kernel
 * can own authoritatively is not duplicated into a userland-written copy that
 * then needs a collector.  Userland reads and writes it through the registry
 * seam (`sys.proc.<pid>.env.<NAME>`), so there is ONE representation.
 *
 * Inheritance follows a COPY at spawn, not a live reference to the parent.  A
 * reference would be cheaper, but it would mean a parent's later `setenv` (or
 * its death) silently rewrote a running child's environment — POSIX snapshots,
 * and so do we.
 *
 * Sized to fit in a single page, which is also the allocation unit: 24 entries
 * of 32+128 bytes.  A bound is unavoidable somewhere; making it the page keeps
 * allocation trivial (pmm_alloc_page returns zeroed memory) and the limit
 * honest and visible rather than emergent. */
#define ENV_KEY_MAX 32
#define ENV_VAL_MAX 128
#define ENV_MAX 24
struct env_entry {
  char k[ENV_KEY_MAX]; /* empty k == free slot */
  char v[ENV_VAL_MAX];
};
struct env_block {
  struct env_entry e[ENV_MAX];
};

/* Process Control Block */
struct process {
  uint32_t pid;
  char name[PROCESS_NAME_MAX];

  /* Memory */
  uint64_t *page_table; /* Physical address of TTBR0_EL1 */
  /* Address-space tag for TLB-tagged context switches (perf §3 / DIR-06 HAL).
   * Architecture-neutral name: the ISA layer maps it to its native tag — ASID
   * on aarch64 (TTBR0_EL1[63:48]), PCID on amd64 (CR3[11:0]).  Assigned in
   * process_create() as (pool slot + 1), so it is unique among the <=
   * MAX_PROCESSES live address spaces by construction (no generation/rollover
   * needed); 0 is reserved for the kernel/idle address space.  The HAL uses it
   * to switch address space WITHOUT a full TLB flush; teardown's
   * arch_tlb_shootdown_all() clears the tag before its slot is recycled. */
  uint16_t asid;
  uint64_t kernel_stack; /* Kernel stack top */
  uint64_t heap_start;   /* Base address of user heap */
  uint64_t heap_end;     /* Current end of user heap */
  spinlock_t mm_lock;    /* Protects page table modifications */

  /* Context for switching */
  struct pt_regs *context;

  /* User Context (Initial) */
  uint64_t user_entry;
  uint64_t user_stack;

  /* State, Priority and Permissions */
  int state;
  uint8_t first_run; /* 1 if never scheduled before (ELF context intact) */
  uint8_t
      kill_pending;  /* SCHED-UAF (Pitfall B): a kill of this PROC_CREATED
                      * child was DEFERRED (it is mid-construction in
                      * dispatch_spawn); process_finalize_spawn() releases it
                      * instead of enqueuing, so the immediate-free path can
                      * never pull the page table out from under the ELF load. */
  uint8_t reaping;   /* SCHED-UAF: set once when the process is queued for the
                      * deferred reaper (reap_push); a second push (prev==DEAD on
                      * one CPU racing a stale runqueue pick on another) is
                      * dropped, so its pages are never double-freed. */
  uint8_t dying;     /* set by process_terminate BEFORE it tears down this
                      * process's windows; SYS_CREATE_WINDOW refuses for a dying
                      * process, so it cannot orphan a fresh window created after
                      * the teardown (the un-closeable-window leak). */
  int exit_code;     /* low byte of status passed to sys_exit() (Phase 2);
                      * collected by a waiter via process_wait()'s out-param. */
  uint8_t exited;    /* 1 once sys_exit() ran (voluntary exit); stays 0 if the
                      * process reached the grave via KILL/fault, so a waiter can
                      * tell "Done (N)" from "Killed" (the NEXS stand-in for
                      * WIFEXITED vs WIFSIGNALED — there is no signal model). */
  int priority;      /* 0 (High) - 31 (Low) */
  int time_slice;    /* Ticks remaining */
  int quantum_reset; /* Reset value */

  uint8_t level; /* privilege level (PLVL_*) — see the capability model below */
  uint32_t caps; /* capability mask (CAP_*); machine level bypasses checks */
  /* ctty_win: controlling-terminal window (USR-TTY-01 #123).  Inherited from
   * the spawner at process_create: the launching shell's window.  A process
   * with NO window of its own (a POSIX-like CLI tool) writes stdout here, so
   * it runs "in the shell"; a process that opens its own window renders there
   * instead (own-window-first in sys_write).  -1 = none. */
  int ctty_win;
  /* self_rendered: set the first time this process calls SYS_WINDOW_BLIT on
   * its OWN window (syscall_dispatch.c) — it owns a custom pixel buffer it
   * composites itself (nxbar/nxui/nxlauncher/nxsettings/nxfilem/demo3d/
   * doom/any SDL app, ...), as opposed to a plain text console.  Checked by
   * the own-window-first stdout resolution (object.c sys_object_write,
   * syscall_dispatch.c window_text_write) to skip drawing text into that
   * window — text and the app's own blit share the SAME pixel buffer
   * (compositor_window_write's term_write and compositor_blit both target
   * windows[i].buffer), so a stray printf()/crash message would otherwise
   * draw glyphs over the app's own rendering.  UART mirroring is untouched
   * (it happens before this flag is even consulted).  Lives on the
   * process (scheduler), NOT the compositor: the compositor stays a pure
   * rendering/composition engine with no "is this text-safe" policy of its
   * own — this is who-owns-what-content, a process/window-ownership
   * question. */
  int self_rendered;
  /* parent_pid: PID of the process that spawned this one (0 = kernel/boot).
   * Set by process_create() from current_process; used by the SYS_KILL
   * capability check (ABI-04): a process may kill itself or any descendant,
   * and a privileged (machine/root) process may kill anything. */
  int parent_pid;
  /* owner_pid: the LOGICAL parent — who this process belongs to, as opposed to
   * parent_pid, which records who mechanically spawned it (ASTRA §6.5 process
   * capability; maintainer decision Q3, 2026-07-18).
   *
   * These diverge as soon as execution moves behind a service: when the nxexec
   * daemon spawns a program on a shell's behalf, parent_pid is nxexec but the
   * job BELONGS to the shell.  Since kill/stop/cont authority is an ancestry
   * walk, without this the shell would silently lose job control over its own
   * jobs the moment the daemon lands.
   *
   * 0 = unset, meaning "same as parent_pid" (every process today).  Only a
   * PRIVILEGED process may set it, and setting it DELEGATES authority over the
   * child, so it is a capability operation (OBJ_CTL_SETOWNER), not a hint. */
  int owner_pid;
  /* child_count: live (not yet reaped) children of this process
   * (SCHED-DOS-01 #122).  Incremented by process_create() on the creator,
   * decremented when a child's pool slot is released (terminate immediate
   * free / scheduler reap).  Protected by sched_lock. */
  int child_count;

  /* Scheduler List */
  struct list_head run_list;
  struct process *next; /* Legacy Linked list (remove later?) */

  /* Wait Queue (for sleeping) */
  struct wait_queue_head *wait_queue_ptr;
  struct wait_queue_head wait_queue;

  /* Tier 3 timed sleep (docs/TIMER-MODEL.md §4): a per-process software timer,
   * armed on the running core, wakes the process at the ABSOLUTE real-time
   * deadline wake_ns (mono_ns base). The wheel fires on a coarse jiffies edge;
   * the fine wake condition is mono_ns() >= wake_ns, so the process wakes at
   * the right wall-clock instant even if ticks were dropped. 0 = not sleeping.
   * cpu_time_counts: CPU time consumed by this process, accumulated in RAW
   * hardware-counter units across context switches (a cheap subtraction in the
   * scheduler hot path — no divide). Converted to ns only on read via
   * timer_counts_to_ns() for os1_cpu_ns()/ps_info. */
  uint64_t wake_ns;
  uint64_t cpu_time_counts;
  struct timer sleep_timer;

  /* Yield-throttle anti-spin (per-process, docs/TIMER-MODEL.md §4): yield()
   * calls within the current tick are counted in yield_count (for the tick
   * yield_jiffy). Beyond YIELD_SPIN_BUDGET the process is busy-spinning on
   * yield() rather than doing work and is put to sleep until the next tick via
   * sleep_timer, so an unoptimised program cannot keep a core at 100% and
   * freeze the system. */
  uint64_t yield_jiffy;
  uint32_t yield_count;

  /* IPC state */
  int ipc_target_pid; /* PID we want to talk to (-1 for ANY) */
  struct ipc_message
      *ipc_msg; /* User-space pointer to message (for synchronous RECV) */
  struct list_head msg_queue; /* Buffered incoming messages */
  spinlock_t msg_lock;        /* Message queue protection */
  int msg_count; /* SCHED-05: pending messages on msg_queue (flow control) */

  /* SMP state */
  int on_cpu; /* CPU ID running this process, -1 if none */

  /* Filesystem state */
  char cwd[128]; /* Current Working Directory */

  /* Per-process environment (Phase 17), one page, copied from the creator at
   * spawn.  NULL means "no private environment": reads fall through to the
   * system defaults under `sys.env.*`.  That is also the graceful degradation
   * path if the page allocation fails — a spawn is never failed over the
   * environment, the child simply inherits the machine's defaults. */
  struct env_block *env;

  /* Capability handle table (object/capability ABI, kernel/object.h) — the ONE
   * per-process descriptor table (ASTRA §6.2: the fd table folded into it).  A
   * POSIX fd IS a handle (fd N == handle N): process_create() pre-installs
   * handles 0/1/2 as the stdin/stdout/stderr CONSOLE object, open() installs
   * FILE handles >= 3, and the object syscalls share the same table.
   * Unforgeable handles to refcounted kernel objects with attenuable rights;
   * freed by process_handles_destroy() at teardown. */
  struct handle_entry *handles;
};

/* Process States */
#define PROC_UNUSED 0
#define PROC_CREATED 1
#define PROC_RUNNING 2
#define PROC_SLEEPING 3
#define PROC_ZOMBIE 4
#define PROC_DEAD 5
#define PROC_READY 6
#define PROC_STOPPED                                                           \
  7 /* suspended (Ctrl-Z/bg job): off the runqueue until a                     \
     * process_cont() resumes it — modelled on PROC_SLEEPING                 \
     * (Phase 2, job control). */

/* Process Priorities */
#define PROC_PRIO_SYSTEM 0 /* Kernel-level service */
#define PROC_PRIO_ROOT 1   /* Root shells/services */
#define PROC_PRIO_USER 2   /* User applications */
#define PROC_PRIO_IDLE 31  /* Idle task */

/* Capability & privilege-level model (B3, USR-SEC-03 #79).  Levels (PLVL_*)
 * and capability bits (CAP_*) live in the shared api header so the kernel and
 * userland cannot drift. */
#include <caps.h>

/* Capability helpers.  A NULL process is the kernel-internal context and is
 * treated as fully privileged, matching the historical bypass. */
static inline int proc_is_machine(const struct process *p) {
  return !p || p->level == PLVL_MACHINE;
}
static inline int proc_is_privileged(const struct process *p) {
  return !p || p->level <= PLVL_ROOT;
}
static inline int proc_has_cap(const struct process *p, uint32_t cap) {
  return !p || p->level == PLVL_MACHINE || (p->caps & cap) == cap;
}

#define MAX_PROCESSES 128
extern struct process *process_pool[MAX_PROCESSES];

/* SCHED-DOS-01 (#122): anti fork-bomb quotas.  MAX_PROCESSES is only the
 * pool ARRAY bound; the effective limit is derived from usable memory at
 * process_init() (see proc_limit in process.c) and these gates keep a
 * single unprivileged process from exhausting it:
 *   MAX_PROCS_PER_PARENT  live-children quota for non-SYSTEM/ROOT creators;
 *   RESERVED_PROC_SLOTS   slots only SYSTEM/ROOT creators may dig into, so
 *                         kill/respawn recovery stays possible at saturation.
 */
#define MAX_PROCS_PER_PARENT 32
#define RESERVED_PROC_SLOTS 8

/* API */
#include <kernel/cpu.h>
#define current_process (get_cpu_info()->current_task)

/* process_create: spawn at 'level' with that level's default capability
 * preset, clamped monotonically against the creator (see process.c).
 * process_create_caps: same, with an explicit requested capability mask
 * (used by SYS_SPAWN_CAPS) — also clamped to the level ceiling and the
 * creator's caps. */
extern struct process *process_create(const char *name, uint8_t priority,
                                      uint8_t level);
extern struct process *process_create_caps(const char *name, uint8_t priority,
                                           uint8_t level, uint32_t req_caps);
struct process *process_find_by_pid(int pid);
struct process *__process_find_by_pid(int pid);
/* sched_lock — THE global scheduler lock (defined in process.c).  Holding it
 * pins every entry of process_pool[] in place: every teardown path removes a
 * process from the pool UNDER this lock and frees its page only afterwards, so
 * while it is held a `struct process *` obtained from __process_find_by_pid()
 * cannot become a dangling pointer (PROC-REF-01).  Exposed so a subsystem that
 * must operate on ANOTHER process's kernel state (installing a handle into it,
 * reading its handle table) can do lookup+use atomically instead of racing a
 * concurrent exit.  Lock order is sched_lock -> object_lock -> kmalloc_lock;
 * nothing takes them in reverse.  Do NOT sleep or allocate a process's handle
 * table while holding it — refuse instead (see handle_install_into_pid). */
extern spinlock_t sched_lock;
/* proc_pid_is_privileged - privilege of a pid as a VALUE (0/1).  Use this, not
 * process_find_by_pid()+proc_is_privileged(), from any subsystem outside the
 * scheduler: the pointer form both dangles once sched_lock is released and
 * forces sched_lock underneath whatever lock the caller already holds.  The
 * compositor is the reason it exists (see the definition, Pitfall A). */
int proc_pid_is_privileged(int pid) NX_MUST_USE;
/* process_kill_allowed: ABI-04 capability check for SYS_KILL.  Returns
 * non-zero if 'caller' may terminate 'target_pid': itself, any descendant,
 * or anything when it is privileged (machine/root).  Kernel-internal
 * terminate paths (compositor close, init supervision) bypass this and call
 * process_terminate() directly. */
int process_kill_allowed(struct process *caller, int target_pid) NX_MUST_USE;
/* process_set_owner - set a process's LOGICAL parent (owner_pid), so a job
 * spawned BY a service still answers to the client that asked for it.  Only
 * reachable through OBJ_CTL_SETOWNER, which requires DESTROY on the target and
 * a privileged caller (it delegates authority).  0, or -ESRCH if either pid is
 * not live. */
int process_set_owner(int pid, int owner_pid) NX_MUST_USE;
/* proc_get_lineage - spawning parent + LOGICAL owner of a pid (owner falls back
 * to parent when unset).  Lets userland follow inheritance across a service
 * spawn, where the mechanical parent is the service rather than the requester.
 */
int proc_get_lineage(int pid, int *parent, int *owner) NX_MUST_USE;

/* Per-process environment (Phase 17).  The AUTHORITY rule is deliberately the
 * process one, not the registry one: a process may always read and write its
 * OWN environment (calling setenv is ordinary, unprivileged work), and only a
 * privileged process may touch another's.  Routing this through CAP_REG_WRITE
 * because the seam happens to be the registry would have made `setenv` demand
 * system-configuration authority — the wrong ceiling for the operation.
 *
 * proc_env_get   0 on hit, -ENOENT if the process has no such variable.
 * proc_env_set   0, -ESRCH (no such pid), -EPERM, -ENOMEM (block full/OOM).
 *                A NULL/empty value UNSETS, which is what the registry DEL op
 *                and `env -u` both need.
 * proc_env_enum  newline-separated NAMEs into buf; returns length, or -1.
 * proc_env_free  release the block at teardown. */
int proc_env_get(int pid, const char *key, char *buf, size_t size) NX_MUST_USE;
int proc_env_set(struct process *caller, int pid, const char *key,
                 const char *value) NX_MUST_USE;
int proc_env_enum(int pid, char *buf, size_t size) NX_MUST_USE;
void proc_env_free(struct process *p);
/* process_ipc_allowed: may 'caller' send IPC to target_pid?  True if the
 * caller holds CAP_IPC_ANY, or target is the caller's parent or a
 * descendant.  Acquires sched_lock internally. */
int process_ipc_allowed(struct process *caller, int target_pid) NX_MUST_USE;
int process_terminate(int pid) NX_MUST_USE;
/* dispatch_spawn finalization (SCHED-UAF Pitfall B): the creator calls one of
 * these AFTER process_load_elf_args (local IRQs off) to commit the new child
 * atomically against a concurrent kill.  finalize: if a kill was deferred
 * (kill_pending) release the child, else enqueue it.  abort: the ELF load
 * failed — release the half-built child. */
void process_finalize_spawn(struct process *p);
void process_abort_spawn(struct process *p);
/* process_kill_subtree - window-aware EXTERNAL kill: terminate root_pid + its
 * WINDOWLESS descendants, SPARE windowed descendants + their subtrees
 * (docs/PROCESS-KILL-MODEL.md).  Used by window_request_close, OBJ_CTL_KILL/
 * CLOSE and SYS_KILL of another process; self-exit/fault stay single-process.
 */
void process_kill_subtree(int root_pid);
/* process_wait - reap-poll a process. Returns pid (reaped), -1 (still alive),
 * or -2 (not found). If out_code != NULL and the process is reaped, *out_code
 * receives its exit_code (raw). Non-blocking. */
int process_wait(int pid, int *out_code) NX_MUST_USE;
/* process_stop/process_cont - suspend/resume a process (job control, Phase 2).
 * stop: RUNNING/READY -> PROC_STOPPED (leaves the runqueue at its next pick).
 * cont: PROC_STOPPED -> READY + re-enqueued. Return 0, -ESRCH (no such pid),
 * or -EINVAL (wrong state). */
int process_stop(int pid) NX_MUST_USE;
int process_cont(int pid) NX_MUST_USE;
extern int process_load_elf(struct process *proc, const char *path);
/* Like process_load_elf(), but marshals an argv vector onto the new task's
 * stack and seeds main()'s argc/argv (kargv holds kernel-side string copies;
 * pass argc=0/kargv=NULL for no arguments). */
extern int process_load_elf_args(struct process *proc, const char *path,
                                 int argc, char *const kargv[]);
void start_user_process(struct process *proc);
void process_init(void);
struct pt_regs *schedule(struct pt_regs *regs);

/* Exception Handlers */
struct pt_regs *syscall_handler(struct pt_regs *frame);
struct pt_regs *irq_handler(struct pt_regs *frame);
struct pt_regs *sync_handler(struct pt_regs *frame);

/* API Declarations */
void enqueue_task(struct process *p);
void sleep_on(struct wait_queue_head *wq);
void wake_up(struct wait_queue_head *wq);

/* Kernel service threads (ASTRA "every service is a process", kernel side).
 * kthread_create: runnable kernel thread at PROC_PRIO_SYSTEM (no user address
 * space, no stdio), starting at 'entry'.  kthread_block: park the calling
 * kernel thread on 'wq' until wake_up(wq) — built on the arch_cpu_yield() HAL
 * primitive.  The input server is the first consumer (input off the IRQ). */
struct process *kthread_create(const char *name, void (*entry)(void));
void kthread_block(struct wait_queue_head *wq, int (*still_block)(void *),
                   void *arg);

/* Core Tasks */
void idle_task_entry(void);

/* Syscalls */
int sys_ipc_send(int target_pid, void *msg_ptr) NX_MUST_USE;
/* sys_ipc_recv returns IPC_RECV_RETRY when it annotated a syscall retry
 * (blocked, or a message slipped in during the sleep window).  The
 * dispatcher must NOT write a return value in that case: on aarch64 x0 is
 * both the return register and arg0, so writing it clobbers src_pid for
 * the re-executed SVC (the receiver re-armed with src_pid=0 and slept
 * forever on a non-empty queue — the visible half of IPC-01). */
#define IPC_RECV_RETRY 1
int sys_ipc_recv(int src_pid, void *msg_ptr) NX_MUST_USE;
int sys_ipc_try_recv(int src_pid, void *msg_ptr) NX_MUST_USE;
int kernel_ipc_send(int target_pid, struct ipc_message *msg) NX_MUST_USE;
struct ipc_node *pop_message(struct process *proc, int src_pid);
/* keyboard_focus_pid: scheduler-owned focus HINT (which PID keystrokes route to
 * and the schedule() focus boost favours). MUTATE ONLY via
 * sched_set_focus_pid() — the compositor and SYS_SET_FOCUS PUSH changes down to
 * the scheduler (GFX-COMP-01 #67); the compositor no longer writes this global
 * directly. It is a single int, so accesses are atomic and reads are lockless:
 * it is a hint, never load-bearing for correctness. Read via
 * sched_get_focus_pid() (snapshot) outside the compositor's own render path. */
extern int keyboard_focus_pid;
void sched_set_focus_pid(int pid);
int sched_get_focus_pid(void) NX_MUST_USE;
/* window_request_close: window-close intent seam (GFX-COMP-03 #69) — the
 * compositor calls this instead of process_terminate() so graphics does not
 * drive process lifecycle directly. */
void window_request_close(int pid);
long sys_getprocs(struct ps_info *user_buf, size_t max_count) NX_MUST_USE;
/* Kernel-internal process introspection backing the OBJ_TYPE_PROCESS object
 * read (a process reports its state through the object mechanism,
 * kernel/core/object.c). proc_get_info: snapshot one pid into *out (0, or -1 if
 * no such live proc). proc_state_name: human-readable PROC_* state. */
int proc_get_info(int pid, struct ps_info *out) NX_MUST_USE;
const char *proc_state_name(int state);
int proc_enum_pids(int *pids, int max)
    NX_MUST_USE; /* live pids -> 'pids' (cap 'max'); /proc listing */
/* OS1_sys_stats backend: one struct os1_sysstats snapshot to userland (perf
 * brief §1 instrumentation surface).  Forward-declared struct; the full layout
 * lives in include/api/sysstats.h. */
struct os1_sysstats;
long sys_sysstats(struct os1_sysstats *user_buf, size_t buf_size) NX_MUST_USE;
long sys_sbrk(intptr_t increment) NX_MUST_USE;

#endif