/*
 * kernel/include/kernel/string.h
 * String function declarations
 */
#ifndef _KERNEL_STRING_H
#define _KERNEL_STRING_H

#include <kernel/nx_contract.h>
#include <kernel/types.h>

size_t strlen(const char *s);
size_t strnlen(const char *s, size_t maxlen);
int strcmp(const char *s1, const char *s2) NX_MUST_USE;
int strncmp(const char *s1, const char *s2, size_t n) NX_MUST_USE;
char *strcpy(char *dest, const char *src) __attribute__((deprecated("use strlcpy/strlcat")));
char *strncpy(char *dest, const char *src, size_t n);
size_t strlcpy(char *dest, const char *src, size_t size);
char *strcat(char *dest, const char *src) __attribute__((deprecated("use strlcpy/strlcat")));
char *strncat(char *dest, const char *src, size_t n);
size_t strlcat(char *dest, const char *src, size_t size);
char *strchr(const char *s, int c);
char *strrchr(const char *s, int c);
char *strstr(const char *haystack, const char *needle);

void *memset(void *s, int c, size_t n);
void *memcpy(void *dest, const void *src, size_t n);
void *memmove(void *dest, const void *src, size_t n);
int memcmp(const void *s1, const void *s2, size_t n) NX_MUST_USE;
void *memchr(const void *s, int c, size_t n);
void bzero(void *s, size_t n);
int strcasecmp(const char *s1, const char *s2) NX_MUST_USE;
int strncasecmp(const char *s1, const char *s2, size_t n) NX_MUST_USE;
int atoi(const char *s) NX_MUST_USE;
uint32_t crc32(const void *data, size_t n_bytes);

#endif /* _KERNEL_STRING_H */
