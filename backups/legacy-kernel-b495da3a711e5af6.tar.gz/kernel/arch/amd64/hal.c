/*
 * kernel/arch/amd64/hal.c
 * AMD64 Hardware Abstraction Layer — PCI Bus Scan and Timer Init
 *
 * Responsibilities:
 *   - amd64_pci_callback: called by pci_enumerate for each discovered PCI
 *     function; enables Bus Master + I/O + Memory access, reads BAR0 and BAR4,
 *     translates VirtIO device IDs, assigns the IRQ, and registers the device
 *     with the HAL device table via hal_register_device.
 *   - arch_bus_scan: invokes pci_enumerate(amd64_pci_callback) to build the
 *     HAL device list.
 *   - arch_irq_init: initialises the legacy 8259 PIC.
 *   - arch_timer_init: runs LAPIC calibration once on the BSP.
 *   - timer_init_percpu: starts the per-CPU LAPIC periodic timer at HZ.
 *
 * Known issues:
 *   DRV-VIRTIO-01 (W5 BUG) pci_get_bar (pci.c:106) returns uint32_t.  For
 *     64-bit BAR entries (type bits [2:1] = 0b10), the high 32 bits of the
 *     MMIO base address are in the NEXT BAR register and are not read.  When
 *     QEMU places the virtio-blk BAR above 4 GB ('-m 4G'), the low 32 bits
 *     returned by pci_get_bar(bdf, 4) are 0 or an alias, so dev->base is
 *     wrong.  The virtio driver reads QUEUE_NUM_MAX from the wrong address and
 *     gets 0 → "Invalid queue size (0)!" → downstream divide-by-zero crash.
 *     Cross-ref: DRV-PCI-02 (pci.c:106-111).
 *     Fix: in amd64_pci_callback, after reading b4, check bits [2:1]; if 10b,
 *     read BAR5 and compose a uint64_t base address.
 */
#include <arch/amd64/apic.h>
#include <drivers/pci.h>
#include <drivers/timer.h>
#include <kernel/hal.h>
#include <kernel/multiboot2.h>
#include <kernel/platform.h>
#include <kernel/printk.h>
#include <kernel/string.h>

/* arch_platform_get_boot_module (HAL contract, platform.h): walk the GRUB
 * multiboot2 tag chain for a MODULE (the release rootfs disk.img loaded into
 * RAM).  Cached on first call (invoked early, before the identity map is torn
 * down) so later callers — the ramdisk backend after vmm_init — still get it.
 * mb_magic / arch_get_boot_info() come from this arch's boot stub. */
extern uint64_t mb_magic;
uint64_t arch_get_boot_info(void);

int arch_platform_get_boot_module(uint64_t *base, uint64_t *size) {
  static int probed = 0;
  static uint64_t mod_base, mod_size;
  if (!probed) {
    probed = 1;
    if (mb_magic == MB2_MAGIC) {
      uint8_t *d = (uint8_t *)arch_get_boot_info();
      if (d) {
        struct mb2_tag *tag = (struct mb2_tag *)(d + 8);
        while (tag->type != MB2_TAG_TYPE_END) {
          if (tag->type == MB2_TAG_TYPE_MODULE) {
            struct mb2_tag_module *m = (struct mb2_tag_module *)tag;
            mod_base = m->mod_start;
            mod_size = (uint64_t)m->mod_end - m->mod_start;
            break;
          }
          tag = (struct mb2_tag *)((uint8_t *)tag + ((tag->size + 7) & ~7u));
        }
      }
    }
  }
  if (mod_base) {
    if (base)
      *base = mod_base;
    if (size)
      *size = mod_size;
    return 1;
  }
  return 0;
}

static void amd64_pci_callback(int bdf, uint16_t vendor, uint16_t device_id) {
  struct hal_device dev;
  memset(&dev, 0, sizeof(dev));

  dev.bus_type = HAL_BUS_TYPE_PCI;
  dev.vendor_id = vendor;
  dev.device_id = device_id;
  dev.pci_bdf = (uint32_t)bdf;

  /* Class triplet (offset 0x08): lets the driver-binding layer match generic
   * controllers (xHCI/AHCI/VGA/NVMe) by function instead of vendor:device. */
  uint32_t cls = pci_get_class(bdf);
  dev.class_code = (cls >> 24) & 0xFF;
  dev.subclass = (cls >> 16) & 0xFF;
  dev.prog_if = (cls >> 8) & 0xFF;
  dev.header_type = pci_get_header_type(bdf);

  /* Enable PCI Bus Master and IO/Mem space */
  uint32_t cmd =
      pci_config_read((bdf >> 16) & 0xFF, (bdf >> 8) & 0xFF, bdf & 0x7, 0x04);
  pci_config_write((bdf >> 16) & 0xFF, (bdf >> 8) & 0xFF, bdf & 0x7, 0x04,
                   cmd | 0x7);

  /* Get BAR address. Modern devices use BAR4 for MMIO usually. Legacy uses BAR0
   * for Port I/O. */
  uint32_t b0 = pci_get_bar(bdf, 0);
  uint32_t b4 = pci_get_bar(bdf, 4);

  bool is_modern = (vendor == 0x1AF4 && device_id >= 0x1041);

  if (is_modern && b4 != 0 && !(b4 & 1)) {
    /* FIX(DRV-VIRTIO-01): read the FULL 64-bit BAR. For a 64-bit memory BAR
     * (type bits [2:1] == 0b10) the high 32 bits live in BAR5; reading only
     * BAR4 truncates the base when QEMU places it above 4GB ('-m 4G'),
     * yielding a wrong dev.base -> virtio reads QUEUE_NUM_MAX as 0 -> crash. */
    dev.base = (uintptr_t)(b4 & ~0xFU);
    if ((b4 & 0x6) == 0x4) { /* 64-bit memory BAR */
      uint32_t b5 = pci_get_bar(bdf, 5);
      dev.base |= ((uintptr_t)b5 << 32);
    }
    /* FIX(AMMU-07): map the BAR MMIO so it is reachable even above 4GB
     * (the fixed 0xFE000000-0xFFFFFFFF identity window does not cover it). */
    extern int arch_vmm_map_device(uint64_t base, uint64_t size);
    arch_vmm_map_device(dev.base, 0x10000);
  } else {
    dev.base = b0;
    if (dev.base & 1)
      dev.base &= ~3;
    else
      dev.base &= ~0xF;
  }

  /* Handle VirtIO ID translation */
  if (vendor == 0x1AF4) {
    if (is_modern) {
      dev.device_id = device_id - 0x1040;
    } else {
      /* Legacy device: Use Subsystem Device ID for type */
      uint32_t sub_id = pci_config_read((bdf >> 16) & 0xFF, (bdf >> 8) & 0xFF,
                                        bdf & 0x7, 0x2C);
      dev.device_id = sub_id >> 16;
    }
  }

  /* dev.irq: PCI Interrupt Line register (config offset 0x3C) is firmware-
   * written and, per the PCI spec, 0xFF means "no legacy line assigned"
   * (or simply not programmed on firmware that skips this field on real
   * boards, unlike QEMU/SeaBIOS which always sets it).  32 + 0xFF = 287
   * is a vector this driver's PIC chip (32-47) never masks/unmasks/EOIs,
   * so the device silently gets an IRQ it can never receive — no crash,
   * no log, just a dead input/block/gpu device on affected hardware.
   * aarch64's virtio.c never trusts firmware for this: every virtio-mmio
   * slot gets a fixed, sequential IRQ (48 + slot index) assigned by this
   * kernel itself.  Mirror that here instead of trusting an unvalidated
   * PCI field: reject the sentinel/out-of-range case explicitly and fall
   * back to a fixed, kernel-assigned vector per bus/device/function so
   * every enumerated device always gets a receivable IRQ. */
  {
    uint8_t line = pci_get_interrupt(bdf);
    if (line == 0xFF || line >= 16) {
      /* PCI_INTLINE_FALLBACK_BASE: reserved for enumerated devices whose
       * firmware-assigned Interrupt Line is missing/invalid.  224-231 is
       * unused by both the legacy 8259 remap (32-47) and every other
       * fixed vector this tree assigns; bdf is folded down to keep each
       * device on a distinct, stable, deterministic vector across boots.
       *
       * FIX(HAL-IRQFALLBACK-01): the fold used to be '& 0x1F' (5 bits),
       * which can reach 224+31 = 255 = 0xFF — the LAPIC spurious vector.
       * amd64_isr_dispatch() special-cases vec==0xFF as "not a real
       * interrupt, return with no dispatch and no EOI" (matching the
       * LAPIC spurious-vector contract in the SVR). A device that actually
       * landed on 255 this way would have every interrupt it raises
       * silently dropped forever — no dispatch, no EOI, no log — which is
       * indistinguishable from a dead device and, for a level-triggered
       * line an unacknowledged vector can leave logically stuck, a
       * candidate for a wider stall. With this codebase's current bdf
       * encoding (function occupies only bits 0-2, bits 3-7 are always
       * zero) the old mask never actually reached 0xFF, but nothing
       * enforced that invariant here — folding on the PCI function field's
       * real width ('& 0x7', matching every other bdf-to-function use in
       * this same function just below) makes the ceiling 224+7 = 231
       * structurally, not incidentally, safe. */
      uint32_t fallback = 224 + ((uint32_t)bdf & 0x7);
      pr_warn("HAL: PCI %02x:%02x.%x has no usable Interrupt Line (0x%x) — "
              "assigning fallback vector %u\n",
              (bdf >> 16) & 0xFF, (bdf >> 8) & 0xFF, bdf & 0x7, line, fallback);
      dev.irq = fallback;
    } else {
      dev.irq = 32 + line;
    }
  }

  /* Basic naming */
  if (vendor == 0x1AF4) {
    snprintf(dev.name, sizeof(dev.name), "VirtIO-%d", device_id);
  } else {
    snprintf(dev.name, sizeof(dev.name), "PCI-%04x:%04x", vendor, device_id);
  }

  hal_register_device(&dev);
}

void arch_bus_scan(void) {
  pr_info("%s", "HAL: Scanning PCI Bus...\n");
  pci_enumerate(amd64_pci_callback);
}

void arch_irq_init(void) {
  extern void pic_init(void);
  pic_init();
}

void arch_timer_init(void) {
  /* BSP Global Timer initialization.
   * We perform LAPIC calibration here once using the legacy PIT. */
  pr_info("HAL: Initializing global timer state (LAPIC calibration)\n");
  lapic_timer_calibrate();
}

void timer_init_percpu(void) {
  /* Initialize local APIC timer for the current CPU at configured HZ.
   * This is called by every CPU during its local initialization. */
  lapic_timer_setup(HZ);
}