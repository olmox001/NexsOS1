/*
 * kernel/drivers/virtio/virtio_input.c
 * VirtIO Input Device Driver (Keyboard/Mouse)
 * Full Virtqueue and Interrupt Implementation
 */
#include <drivers/keyboard.h>
#include <drivers/virtio.h>
#include <drivers/virtio_input.h>
#include <kernel/arch.h>
#include <kernel/graphics.h>
#include <kernel/irq.h>
#include <kernel/pmm.h>
#include <kernel/printk.h>
#include <kernel/string.h>
#include <kernel/types.h>
#include <kernel/vmm.h>

#ifdef ARCH_AMD64
#include <drivers/pci.h>
#endif

extern void compositor_update_mouse(int dx, int dy, int absolute);

#define MAX_INPUT_DEVS 2
#define INPUT_QSIZE 16

void virtio_input_add_event(uint16_t type, uint16_t code, int32_t value);

struct virtio_input_dev {
  virtio_handle_t handle;
  uint32_t irq;
  int active;
  int is_pci;
  struct vring_desc *desc;
  struct vring_avail *avail;
  struct vring_used *used;
  uint16_t last_used_idx;
  struct virtio_input_event *events;
};

static struct virtio_input_dev input_devs[MAX_INPUT_DEVS];
static int input_dev_count = 0;

/* Global Input Buffer (Shared by all devices) */
#define INPUT_BUFFER_SIZE 256
static struct virtio_input_event input_buffer[INPUT_BUFFER_SIZE];
static volatile uint32_t input_head = 0;
static volatile uint32_t input_tail = 0;

/* Forward declarations */
static void virtio_input_handler(uint32_t irq, void *data);

/* Helper macros / functions for transport abstraction */
#define v_read32(dev, off) virtio_read_reg((dev)->handle, (off))
#define v_write32(dev, off, val) virtio_write_reg((dev)->handle, (off), (val))
#define v_notify(dev, q) virtio_notify((dev)->handle, (q))

void virtio_input_add_event(uint16_t type, uint16_t code, int32_t value) {
  uint32_t next = (input_head + 1) % INPUT_BUFFER_SIZE;
  if (next == input_tail) {
    input_tail = (input_tail + 1) % INPUT_BUFFER_SIZE;
  }
  input_buffer[input_head].type = type;
  input_buffer[input_head].code = code;
  input_buffer[input_head].value = value;
  input_head = next;
}

static void init_device(virtio_handle_t handle, uint32_t irq, int is_pci) {
  (void)is_pci;
  if (input_dev_count >= MAX_INPUT_DEVS)
    return;

  struct virtio_input_dev *dev = &input_devs[input_dev_count++];
  dev->handle = handle;
  dev->irq = irq;
  dev->active = 0;

  /* Reset */
  v_write32(dev, VIRTIO_MMIO_STATUS, 0);
  v_write32(dev, VIRTIO_MMIO_STATUS,
            VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER);

  /* Features */
  v_write32(dev, VIRTIO_MMIO_DRIVER_FEATURES, 0);
  v_write32(dev, VIRTIO_MMIO_STATUS,
            v_read32(dev, VIRTIO_MMIO_STATUS) | VIRTIO_STATUS_FEATURES_OK);

  /* Setup Queue 0 (eventq) */
  v_write32(dev, VIRTIO_MMIO_QUEUE_SEL, 0);
  v_write32(dev, VIRTIO_MMIO_QUEUE_NUM, INPUT_QSIZE);

  void *qmem = pmm_alloc_pages_dma(2);
  if (!qmem) {
    /* DRV-VIRTIO-07: bail out gracefully instead of NULL-dereferencing. */
    pr_err("%s", "VirtIO-Input: failed to allocate virtqueue memory\n");
    input_dev_count--;
    return;
  }
  memset(qmem, 0, 8192);
  dev->desc = (struct vring_desc *)qmem;
  dev->avail = (struct vring_avail *)((uint8_t *)qmem + INPUT_QSIZE * 16);
  dev->used = (struct vring_used *)((uint8_t *)qmem + 4096);

  /* Use unified HAL API; the device needs PHYSICAL ring addresses. */
  virtio_setup_queue(handle, 0, virt_to_phys(dev->desc),
                     virt_to_phys(dev->avail), virt_to_phys(dev->used));

  dev->events = (struct virtio_input_event *)pmm_alloc_page_dma();
  if (!dev->events) {
    /* DRV-VIRTIO-07: free the virtqueue memory and bail out gracefully. */
    pr_err("%s", "VirtIO-Input: failed to allocate events buffer\n");
    pmm_free_pages(qmem, 2);
    input_dev_count--;
    return;
  }
  memset(dev->events, 0, sizeof(struct virtio_input_event) * INPUT_QSIZE);

  for (int i = 0; i < INPUT_QSIZE; i++) {
    /* Descriptor addresses are PHYSICAL (DMA). */
    dev->desc[i].addr = virt_to_phys(&dev->events[i]);
    dev->desc[i].len = sizeof(struct virtio_input_event);
    dev->desc[i].flags = VRING_DESC_F_WRITE;
    dev->avail->ring[i] = i;
  }
  dev->avail->idx = INPUT_QSIZE;
  dev->last_used_idx = 0;

  /* FIX(VINPUT-DMA-04): the device DMA-reads desc[]/avail as soon as
   * v_notify() below runs; pmm_alloc_pages_dma() only cache-cleaned the
   * freshly-zeroed page once, at allocation, not the descriptor table and
   * available-ring contents just written above. Same hazard class as
   * VGPU-DMA-02/VBLK-DMA-02: without this, whether the device's very
   * first read of this queue sees valid descriptors depends on unrelated
   * cache state on real hardware, and is always fine under QEMU/KVM. */
  arch_cache_clean_range((void *)dev->desc, INPUT_QSIZE * sizeof(*dev->desc));
  arch_cache_clean_range((void *)dev->avail, sizeof(*dev->avail));
  arch_mb();

  /* Driver OK */
  v_write32(dev, VIRTIO_MMIO_STATUS,
            v_read32(dev, VIRTIO_MMIO_STATUS) | VIRTIO_STATUS_DRIVER_OK);

  /* Register and Enable Interrupt */
  /* A device whose IRQ line is not wired delivers nothing: no keystrokes, no
   * mouse.  Dropping this made that look like a dead device rather than a
   * failed registration. */
  if (irq_register(irq, virtio_input_handler, dev) != 0)
    pr_err("virtio-input: cannot register IRQ %u — this device will deliver no "
           "events\n",
           irq);

  /* Notify device */
  v_notify(dev, 0);

  dev->active = 1;
}

static void virtio_input_handler(uint32_t irq, void *data) {
  (void)data; /* Parametro ignorato a favore del polling vettoriale */

  for (int i = 0; i < input_dev_count; i++) {
    struct virtio_input_dev *dev = &input_devs[i];

    /* Filtra i dispositivi disattivi o non pertinenti all'IRQ sollevato */
    if (!dev->active || dev->irq != irq) {
      continue;
    }

    uint32_t status = v_read32(dev, VIRTIO_MMIO_INTERRUPT_STATUS);
    uint16_t processed_count = 0;

    /* FIX(VINPUT-DMA-01): the device writes dev->used (idx + ring entries)
     * via DMA every time it reports an event; this CPU's cache can hold a
     * stale copy of that line from before the event arrived. Without
     * invalidating it here, this IRQ handler can read a used->idx this
     * core already had cached — the same value as last time — and see NO
     * new event at all, even though the device already wrote one to RAM.
     * That is a hardware-timing-dependent "dropped IRQ" that depends on
     * unrelated cache state, never reproducible under QEMU/KVM's emulated
     * (always-coherent) memory: exactly the "works only after moving the
     * mouse enough times" symptom this device's IRQ was implicated in. */
    arch_cache_invalidate_range((void *)dev->used, sizeof(*dev->used));

    while (dev->last_used_idx != dev->used->idx) {
      struct vring_used_elem *e =
          &dev->used->ring[dev->last_used_idx % INPUT_QSIZE];
      uint32_t id = e->id;

      /* FIX(VINPUT-DMA-02): dev->events[id] is the DMA target the device
       * just wrote the actual event payload (type/code/value) into — a
       * separate cache line from dev->used, and just as capable of being
       * stale in this CPU's cache. */
      arch_cache_invalidate_range((void *)&dev->events[id],
                                  sizeof(dev->events[id]));
      struct virtio_input_event *evt = &dev->events[id];

      /* Single dispatch point: keys -> keyboard/IPC, pointer -> compositor,
       * EV_SYN -> repaint. Same path PS/2 and USB HID use now. */
      input_report(evt->type, evt->code, evt->value);

      dev->avail->ring[dev->avail->idx % INPUT_QSIZE] = id;
      dev->avail->idx++;
      dev->last_used_idx++;
      processed_count++;
    }

    /* FIX(VINPUT-DMA-03): the device DMA-reads dev->avail to learn which
     * descriptor slots are free again (recycled just above); clean it so
     * those writes are actually visible to the device's next DMA read,
     * for the same reason as virtio_gpu.c's virtio_gpu_send()
     * (VGPU-DMA-02) — arch_mb() alone does not push a dirty cache line
     * out to physical RAM. Done once per IRQ, after the recycle loop,
     * instead of per-iteration: avail is only consumed by the device on
     * the v_notify() below, not before. */
    if (processed_count > 0) {
      arch_cache_clean_range((void *)dev->avail, sizeof(*dev->avail));
      arch_mb();
    }

    if (status != 0) {
      v_write32(dev, VIRTIO_MMIO_INTERRUPT_ACK, status);
    } else if (processed_count == 0) {
      v_read32(dev, VIRTIO_MMIO_INTERRUPT_ACK);
    }

    if (processed_count > 0) {
      v_notify(dev, 0);
    }
  }
}

void virtio_input_init(void) {
  pr_info("%s", "VirtIO-Input: Probing devices...\n");
  input_dev_count = 0; // reset

  int count = arch_virtio_get_count(VIRTIO_DEV_INPUT);
  for (int i = 0; i < count; i++) {
    virtio_handle_t dev = NULL;
    uint32_t irq = 0;
    if (arch_virtio_get_device(VIRTIO_DEV_INPUT, i, &dev, &irq) == 0) {
      init_device(dev, irq, 0);
    }
  }

  if (input_dev_count > 0) {
    pr_info("VirtIO-Input: %d input device(s) initialized\n", input_dev_count);
  }
}
int virtio_input_get_dev_count(void) { return input_dev_count; }

int virtio_input_poll(struct virtio_input_event *event) {
  if (input_head == input_tail)
    return 0;
  *event = input_buffer[input_tail];
  input_tail = (input_tail + 1) % INPUT_BUFFER_SIZE;
  return 1;
}

int virtio_input_has_event(void) { return input_head != input_tail; }