/*
 * kernel/core/fault.c
 * Generic user-vs-kernel fault decision (Phase A step 8).
 *
 * Both HAL exception dispatchers route recoverable-fault classification
 * through fault_handle_user_or_panic():
 *
 *   - fault from user mode (CS RPL==3 on amd64, SPSR.M==EL0t on aarch64), or
 *   - fault from kernel mode while arch_copy_{from,to}_user was dereferencing
 *     user memory (per-CPU uaccess_active set, fault address in user VA)
 *
 *   -> log, terminate the process, return schedule()'s next frame.
 *
 * Everything else is a kernel bug: the function returns NULL and the caller
 * performs its arch-specific register dump and panics (panic() is fault-safe
 * here because the dispatcher's fault_enter() depth is still held).
 *
 * The uaccess_active gate is the CPU-AARCH64-01 fix: a wild kernel pointer
 * that merely happens to land in user VA range is NOT recoverable and must
 * panic; only a fault raised by the explicit user-copy window may terminate
 * the process and continue.
 */
#include <kernel/nx_contract.h>
#include <kernel/cpu.h>
#include <kernel/fault.h>
#include <kernel/printk.h>
#include <kernel/registry.h>
#include <kernel/sched.h>
#include <kernel/string.h>
#include <kernel/types.h>
#include <kernel/vmm.h>

extern struct pt_regs *schedule(struct pt_regs *regs);
extern int process_terminate(int pid);

/* fault_notify_user - post a RED notification (severity 2) about a crashing user
 * process to the notification server (nxntfy_srv), so a userland crash is visible
 * ON SCREEN, not only on the UART.  Best-effort: skipped if the server is not up
 * (registry key srv.notify_pid absent).  Safe in this path: a user fault leaves
 * the kernel healthy, so registry_get + kernel_ipc_send are ordinary calls. */
static void fault_notify_user(struct process *task, const char *desc) {
  char pidbuf[16];
  if (registry_get("srv.notify_pid", pidbuf, sizeof(pidbuf)) != 0)
    return;
  int npid = atoi(pidbuf);
  if (npid <= 0)
    return;
  struct ipc_message m;
  m.from = task->pid; /* group the crash notification under the crashing process */
  m.type = IPC_TYPE_NOTIFY;
  m.data1 = 2; /* severity: error -> red popup (1 = warning/yellow, 0 = info) */
  m.data2 = (uint64_t)task->pid;
  snprintf(m.payload, sizeof(m.payload), "%s crashed: %s", task->name, desc);
  /* DIR-05's contract is that a userland crash is VISIBLE, not that an IPC was
   * attempted.  Discarding the result satisfied the letter and lost the point:
   * when the notification server is wedged or its queue is full -- exactly the
   * moment a crash matters most -- the popup silently never appears and the
   * only trace is gone.  So the failure falls back to the channel that cannot
   * itself be full. */
  if (kernel_ipc_send(npid, &m) != 0)
    fault_printf("[FAULT] crash popup NOT delivered to the notify server "
                 "(pid %d): %s\n",
                 npid, m.payload);
}

struct pt_regs *fault_handle_user_or_panic(struct pt_regs *regs, int user_mode,
                                           uint64_t fault_addr, uint64_t fault_pc,
                                           const char *desc, uint64_t syndrome) {
  /* Fault context: locate per-CPU state via the MSR/MPIDR path, never via
   * the LAPIC-MMIO read (kernel/fault.h). */
  struct cpu_info *ci = arch_cpu_info_fault_safe();
  struct process *task = ci ? ci->current_task : NULL;

  int uaccess = (!user_mode && ci && ci->uaccess_active &&
                 vmm_is_user_addr(fault_addr));

  if ((user_mode || uaccess) && task) {
    /* User-attributable fault: the kernel itself is healthy.  fault_printf
     * is still used (not printk) because on the uaccess path we may hold
     * arch-side locks until the fixup below. */
    fault_printf("\n[FAULT] %s%s: PID %d (%s) pc=0x%016lx addr=0x%016lx cause=0x%016lx — terminating\n",
                 desc, uaccess ? " (uaccess)" : "", task->pid, task->name,
                 fault_pc, fault_addr, syndrome);

    if (uaccess) {
      /* Release the arch uaccess critical section (locks/IRQ state/flag);
       * the address-space switch is reconciled by the scheduler below. */
      arch_uaccess_fault_fixup();
    }

    fault_notify_user(task, desc); /* DIR-05 #139: red crash popup, best-effort */
    /* We are already in the fault handler for this task; there is no caller
     * left to propagate to.  Reported so a teardown that fails does not leave a
     * faulted process silently alive and schedulable. */
    if (process_terminate(task->pid) != 0)
      fault_printf("[FAULT] process_terminate(%d) FAILED after a user fault\n",
                   task->pid);
    fault_exit(); /* fault handled — unwind the recursion guard */
    return schedule(regs);
  }

  /* A USER-attributable fault with no current task is not a kernel fault: it
   * means this CPU took an exception from user mode while its current_task was
   * NULL, i.e. the scheduler state is corrupt.  Naming it here, in the shared
   * decision, is what makes the two architectures agree: aarch64's EL0 vector
   * already panicked with that diagnosis while amd64 fell through and printed
   * "KERNEL PAGE FAULT", classifying the same condition as something else
   * entirely.  Each caller still dumps its own register set — those genuinely
   * differ — but the diagnosis no longer depends on which arch you are on. */
  if ((user_mode || uaccess) && !task)
    fault_printf("\n[FAULT] %s from user mode with NO CURRENT TASK on cpu %d — "
                 "scheduler-state corruption (pc=0x%016lx addr=0x%016lx "
                 "cause=0x%016lx)\n",
                 desc, ci ? (int)ci->cpu_id : -1, fault_pc, fault_addr,
                 syndrome);

  return NULL; /* kernel fault: caller dumps registers and panics */
}
